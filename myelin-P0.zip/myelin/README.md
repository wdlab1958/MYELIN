# MYELIN — Personal Knowledge OS

> 쓸수록 빨라지는 나의 지식 신경망 · *Knowledge that fires faster.*

Obsidian Vault를 정본으로, Claude를 가공 엔진으로 쓰는 개인 지식 운영체계입니다.
각자 자기 Domain을 Pack(YAML)으로 설정하고, 경험을 재사용 가능한 지식으로 전환합니다.

- 정본 명세: [`docs/spec/MYELIN_Rev2.0.md`](docs/spec/MYELIN_Rev2.0.md)
- 진행 상태: [`PHASE_STATE.md`](PHASE_STATE.md)
- Phase 계획: [`docs/phases/`](docs/phases/)

## 구성

| 경로 | 구성요소 | 구현 Phase |
|---|---|---|
| `packages/myelin-core` | 스키마 · 파서 · Pack 로더 · doctor · 색인 | P1 |
| `packages/myelin-cli` | `myelin` CLI (init / add-domain / doctor / stats) | P2 |
| `plugin/` | MYELIN for Claude Code (Skills + Fail-closed Guard) | P3 |
| `packages/myelin-mcp` | MYELIN MCP 서버 | P4 |
| `design/`, `theme/` | Emboss 디자인 시스템 · Obsidian Theme | P5 |
| `packages/myelin-hub` | MYELIN Hub (FastAPI + React) | P6 |
| `packs/` | Domain Packs (core / reference / org) | P1, P7 |

## 개발

```bash
uv sync          # 의존성 설치
make check       # lint + type + test
make gate P=0    # Phase Gate 판정
```

Claude Code로 작업할 때는 `CLAUDE.md` 의 Session Protocol을 따릅니다.
